package com.ninhttd.devtest.custom;

public class LogUtils {
    public static final String PREFIX_TAG="PRISM_";
}
