package com.ninhttd.devtest.data;

public class Test {
}
